package temp;
public enum ComputerType {
	DESKTOP, LAPTOP, TABLET;
}
