package temp;
public class MainClass
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		SellerList GBStore = new SellerList();
		GBStore.processCommands();
	}
} // end of MainClass
